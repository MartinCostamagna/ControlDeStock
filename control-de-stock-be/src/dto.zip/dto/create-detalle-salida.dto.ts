export class CreateDetalleSalidaDto {}
