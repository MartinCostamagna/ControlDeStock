export class CreateSalidaDto {}
