export class CreateDetalleEntradaDto {


}
