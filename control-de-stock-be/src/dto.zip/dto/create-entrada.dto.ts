export class CreateEntradaDto {}
