export class CreatePedidoDto {}
