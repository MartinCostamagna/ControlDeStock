export class CreateDetallePedidoDto {}
